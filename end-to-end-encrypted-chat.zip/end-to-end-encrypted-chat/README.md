# End-to-End Encrypted Chat Application

This is a secure messaging application that uses **AES encryption** and **Diffie-Hellman key exchange** for secure communication.

## How to Run

1. Start the server:
   ```bash
   cd server
   python server.py
   ```
