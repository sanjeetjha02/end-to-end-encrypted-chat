import os
import socket
from cryptography.hazmat.primitives.asymmetric import dh
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# Deserialize DH parameters
def deserialize_parameters(serialized_parameters):
    return serialization.load_pem_parameters(serialized_parameters, backend=default_backend())

# Generate DH key pair
def generate_dh_key_pair(parameters):
    private_key = parameters.generate_private_key()
    public_key = private_key.public_key()
    return private_key, public_key

def serialize_public_key(public_key):
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

def deserialize_public_key(serialized_key):
    return serialization.load_pem_public_key(serialized_key, backend=default_backend())

# Derive shared key
def derive_shared_key(private_key, peer_public_key):
    shared_key = private_key.exchange(peer_public_key)
    derived_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b'handshake data',
        backend=default_backend()
    ).derive(shared_key)
    return derived_key

# AES Encryption and Decryption
def encrypt_message(key, message):
    iv = os.urandom(16)  # Generate a random initialization vector
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(message.encode()) + encryptor.finalize()
    return iv + ciphertext

def decrypt_message(key, ciphertext):
    iv = ciphertext[:16]  # Extract the initialization vector
    ciphertext = ciphertext[16:]
    cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    plaintext = decryptor.update(ciphertext) + decryptor.finalize()
    return plaintext.decode()

# Socket Communication
def start_client():
    # Connect to server
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 12345))
    print("Connected to server.")

    # Receive DH parameters from server
    serialized_parameters = client_socket.recv(4096)
    parameters = deserialize_parameters(serialized_parameters)

    # Generate client's key pair
    private_key, public_key = generate_dh_key_pair(parameters)
    serialized_public_key = serialize_public_key(public_key)

    # Exchange public keys
    peer_serialized_public_key = client_socket.recv(4096)
    client_socket.send(serialized_public_key)
    peer_public_key = deserialize_public_key(peer_serialized_public_key)

    # Derive shared key
    shared_key = derive_shared_key(private_key, peer_public_key)
    print("Shared key derived successfully!")

    # Chat loop
    while True:
        message = input("You: ")
        encrypted_message = encrypt_message(shared_key, message)
        client_socket.send(encrypted_message)

        encrypted_response = client_socket.recv(4096)
        decrypted_response = decrypt_message(shared_key, encrypted_response)
        print(f"Server: {decrypted_response}")

if __name__ == "__main__":
    start_client()